Instructions to run this program:

Just run main.py with all modules to test this program :)